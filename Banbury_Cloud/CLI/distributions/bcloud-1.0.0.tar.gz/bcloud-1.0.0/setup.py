
from setuptools import setup, find_packages

setup(
    name="bcloud",
    version="1.0.0",
    packages=find_packages(),
    description = "A CLI tool",
    long_description="A CLI tool",
    entry_points={
        "console_scripts": [
            "bcloud = bcloud.cli:main",  # Replace with your module and function name
        ],
    },
)
